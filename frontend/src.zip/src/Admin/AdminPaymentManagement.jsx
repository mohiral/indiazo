"use client"

import { useState, useEffect } from "react"
import axios from "axios"

const AdminPaymentManagement = () => {
  const [payments, setPayments] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchPayments()
  }, [])

  const fetchPayments = async () => {
    try {
      setLoading(true)
      const response = await axios.get("https://aviatorbackend.alofficialgroup.com/api/admin/all-payments")
      setPayments(response.data)
      setLoading(false)
    } catch (error) {
      console.error("Error fetching payments:", error)
      setError("Failed to load payments. Please try again later.")
      setLoading(false)
    }
  }

  const handleUpdateStatus = async (paymentId, status) => {
    try {
      const response = await axios.put(`https://aviatorbackend.alofficialgroup.com/api/admin/update-payment-status/${paymentId}`, {
        status,
      })
      if (response.status === 200) {
        fetchPayments()
      } else {
        throw new Error("Unexpected response status")
      }
    } catch (error) {
      console.error("Error updating payment status:", error)
      alert(`Failed to update payment status: ${error.response?.data?.message || error.message}`)
    }
  }

  if (loading) {
    return <div className="text-center py-4">Loading...</div>
  }

  if (error) {
    return <div className="text-red-500 text-center py-4">{error}</div>
  }

  const getStatusColor = (status) => {
    switch (status) {
      case "pending":
        return "text-yellow-500"
      case "confirmed":
        return "text-green-500"
      case "rejected":
        return "text-red-500"
      default:
        return "text-gray-500"
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4 text-center">All Payments</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {payments.map((payment) => (
          <div key={payment._id} className="p-4 bg-white rounded-lg shadow-md">
            <p className="font-semibold">User: {payment.userName}</p>
            <p>Class Name: {payment.className}</p>
            <p>Amount: ${payment.amount.toFixed(2)}</p>
            <p>UTR: {payment.utr}</p>
            <p>UPI ID: {payment.upiId}</p>
            <p>Date: {new Date(payment.createdAt).toLocaleDateString()}</p>
            <p className={`font-medium ${getStatusColor(payment.status)}`}>
              Status: {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
            </p>
            <div className="mt-2 space-x-2">
              {payment.status === "pending" ? (
                <>
                  <button
                    onClick={() => handleUpdateStatus(payment._id, "confirmed")}
                    className="bg-green-500 hover:bg-green-600 text-white font-bold py-1 px-2 rounded"
                  >
                    Accept
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(payment._id, "rejected")}
                    className="bg-red-500 hover:bg-red-600 text-white font-bold py-1 px-2 rounded"
                  >
                    Reject
                  </button>
                </>
              ) : (
                <button
                  onClick={() => handleUpdateStatus(payment._id, "pending")}
                  className="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-1 px-2 rounded"
                >
                  Reset to Pending
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default AdminPaymentManagement
