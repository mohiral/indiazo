"use client"

import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import QRCode from "react-qr-code"
import { motion, AnimatePresence } from "framer-motion"
import { FaRupeeSign, FaQrcode, FaMobileAlt, FaCheckCircle, FaArrowLeft, FaInfoCircle } from "react-icons/fa"

const PaymentQRPage = () => {
  const [amount, setAmount] = useState(500)
  const [showForm, setShowForm] = useState(false)
  const [utr, setUtr] = useState("")
  const [upi, setUpi] = useState("")
  const [user, setUser] = useState({})
  const [isCheckingAuth, setIsCheckingAuth] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [activeTab, setActiveTab] = useState("qr")
  const navigate = useNavigate()
  const upiId = "7568008581@ybl"
  const [isAmountValid, setIsAmountValid] = useState(true)
  const [presetAmounts] = useState([500, 1000, 2000, 5000])

  useEffect(() => {
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
    setIsCheckingAuth(false)
  }, [])

  const generateUpiLink = () => {
    const transactionNote = "Adding money to wallet"
    return `upi://pay?pa=${upiId}&pn=LocalMart&tn=${encodeURIComponent(transactionNote)}&am=${amount}&cu=INR`
  }

  const handleAmountChange = (e) => {
    const value = Number(e.target.value)
    setAmount(value)
    setIsAmountValid(value >= 500)
  }

  const handleSelectAmount = (value) => {
    setAmount(value)
    setIsAmountValid(true)
  }

  const handlePayWithUPI = () => {
    if (isAmountValid) {
      window.location.href = generateUpiLink()
    }
  }

  const handlePaymentDone = () => {
    if (isAmountValid) {
      setShowForm(true)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!isAmountValid) return

    setIsSubmitting(true)

    const paymentData = {
      userId: user.userId || "Unknown",
      userName: user.name || "Unknown",
      userEmail: user.email || "Unknown",
      classId: "abc123",
      className: "React Masterclass",
      amount,
      utr,
      upiId: upi,
    }

    try {
      const response = await fetch("https://aviatorbackend.alofficialgroup.com/api/submit-payment", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(paymentData),
      })

      const result = await response.json()

      if (response.ok) {
        console.log("Payment submitted:", result)
        navigate("/PaymentPage")
      } else {
        console.error("Error:", result.message)
        alert("Payment submission failed.")
      }
    } catch (error) {
      console.error("Error submitting payment:", error)
      alert("An error occurred. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (isCheckingAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-blue-50 to-indigo-100">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-indigo-100 pt-16 pb-20">
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-md mx-auto bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-6 text-white">
            <div className="flex items-center mb-4">
              <button
                onClick={() => navigate("/PaymentPage")}
                className="p-2 rounded-full hover:bg-white hover:bg-opacity-20 transition-colors"
              >
                <FaArrowLeft />
              </button>
              <h2 className="text-2xl font-bold ml-3">Add Money to Wallet</h2>
            </div>
            <p className="text-blue-100">Securely add funds to your gaming wallet</p>
          </div>

          {/* Content */}
          <div className="p-6">
            {/* Amount Input Section */}
            <div className="mb-6">
              <label className="block text-gray-700 font-medium mb-2">Enter Amount</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <FaRupeeSign className="text-gray-500" />
                </div>
                <input
                  type="number"
                  value={amount}
                  onChange={handleAmountChange}
                  min="500"
                  className={`w-full pl-10 pr-4 py-3 border-2 rounded-lg text-lg font-bold ${
                    !isAmountValid
                      ? "border-red-400 focus:border-red-500 focus:ring-red-500"
                      : "border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  } focus:outline-none focus:ring-2 transition-colors`}
                />
              </div>
              {!isAmountValid && (
                <motion.p
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center text-red-500 text-sm mt-1"
                >
                  <FaInfoCircle className="mr-1" /> Amount must be at least ₹500
                </motion.p>
              )}

              {/* Quick Amount Selection */}
              <div className="grid grid-cols-4 gap-2 mt-3">
                {presetAmounts.map((presetAmount) => (
                  <button
                    key={presetAmount}
                    onClick={() => handleSelectAmount(presetAmount)}
                    className={`py-2 px-1 rounded-lg border-2 transition-all ${
                      amount === presetAmount
                        ? "bg-blue-100 border-blue-500 text-blue-700 font-bold"
                        : "bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100"
                    }`}
                  >
                    ₹{presetAmount}
                  </button>
                ))}
              </div>
            </div>

            {/* Payment Method Tabs */}
            <div className="mb-6">
              <div className="flex bg-gray-100 p-1 rounded-lg">
                <button
                  onClick={() => setActiveTab("qr")}
                  className={`flex items-center justify-center w-1/2 py-2 rounded-md transition-all ${
                    activeTab === "qr"
                      ? "bg-white text-blue-600 shadow-sm font-medium"
                      : "text-gray-600 hover:text-gray-800"
                  }`}
                >
                  <FaQrcode className="mr-2" /> QR Code
                </button>
                <button
                  onClick={() => setActiveTab("upi")}
                  className={`flex items-center justify-center w-1/2 py-2 rounded-md transition-all ${
                    activeTab === "upi"
                      ? "bg-white text-blue-600 shadow-sm font-medium"
                      : "text-gray-600 hover:text-gray-800"
                  }`}
                >
                  <FaMobileAlt className="mr-2" /> UPI Apps
                </button>
              </div>
            </div>

            {/* QR Code Display */}
            <AnimatePresence mode="wait">
              {activeTab === "qr" && (
                <motion.div
                  key="qr"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                  className="flex flex-col items-center"
                >
                  <div className="bg-white p-4 rounded-xl shadow-md border-2 border-gray-200 mb-4">
                    <QRCode value={generateUpiLink()} size={200} level="H" className="mx-auto" />
                  </div>
                  <p className="text-center text-gray-600 mb-4">Scan this QR code with any UPI app to pay ₹{amount}</p>
                  <div className="text-center mb-4 w-full">
                    <p className="text-sm text-gray-500 mb-2">UPI ID:</p>
                    <div className="flex items-center justify-center bg-gray-100 py-2 px-4 rounded-lg">
                      <span className="font-medium text-gray-800">{upiId}</span>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === "upi" && (
                <motion.div
                  key="upi"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                  className="flex flex-col"
                >
                  <button
                    onClick={handlePayWithUPI}
                    disabled={!isAmountValid}
                    className={`w-full py-3 px-4 mb-3 rounded-lg font-medium flex items-center justify-center ${
                      isAmountValid
                        ? "bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white"
                        : "bg-gray-300 text-gray-500 cursor-not-allowed"
                    } transition-all duration-300`}
                  >
                    <FaMobileAlt className="mr-2" /> Pay with UPI Apps
                  </button>

                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
                    <p className="text-sm text-blue-700">
                      Clicking the button above will open your UPI app with pre-filled payment details.
                    </p>
                  </div>

                  <div className="flex justify-center">
                    <div className="flex space-x-4">
                      <img
                        src="/placeholder.svg?height=40&width=40"
                        alt="Google Pay"
                        className="h-10 w-10 object-contain"
                      />
                      <img
                        src="/placeholder.svg?height=40&width=40"
                        alt="PhonePe"
                        className="h-10 w-10 object-contain"
                      />
                      <img src="/placeholder.svg?height=40&width=40" alt="Paytm" className="h-10 w-10 object-contain" />
                      <img src="/placeholder.svg?height=40&width=40" alt="BHIM" className="h-10 w-10 object-contain" />
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Payment Done Button */}
            <div className="mt-6 border-t border-gray-200 pt-6">
              <button
                onClick={handlePaymentDone}
                disabled={!isAmountValid}
                className={`w-full py-3 px-4 rounded-lg font-medium flex items-center justify-center ${
                  isAmountValid
                    ? "bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white"
                    : "bg-gray-300 text-gray-500 cursor-not-allowed"
                } transition-all duration-300`}
              >
                <FaCheckCircle className="mr-2" /> I've Completed the Payment
              </button>
            </div>

            {/* UTR Form */}
            <AnimatePresence>
              {showForm && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <form onSubmit={handleSubmit} className="mt-6 bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <h3 className="font-medium text-gray-800 mb-4">Verify Your Payment</h3>

                    <div className="mb-4">
                      <label className="block text-gray-700 text-sm font-medium mb-2">UTR Number</label>
                      <input
                        type="text"
                        value={utr}
                        onChange={(e) => setUtr(e.target.value)}
                        placeholder="Enter 12-digit UTR number"
                        className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        required
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        You can find the UTR number in your UPI app payment history
                      </p>
                    </div>

                    <div className="mb-4">
                      <label className="block text-gray-700 text-sm font-medium mb-2">UPI ID Used</label>
                      <input
                        type="text"
                        value={upi}
                        onChange={(e) => setUpi(e.target.value)}
                        placeholder="e.g. name@bank"
                        className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        required
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className={`w-full py-3 px-4 rounded-lg font-medium ${
                        isSubmitting
                          ? "bg-gray-400 text-white cursor-not-allowed"
                          : "bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 text-white"
                      } transition-all duration-300 flex items-center justify-center`}
                    >
                      {isSubmitting ? (
                        <>
                          <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-white mr-2"></div>
                          Processing...
                        </>
                      ) : (
                        "Verify & Add Money"
                      )}
                    </button>
                  </form>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </div>
  )
}

export default PaymentQRPage

