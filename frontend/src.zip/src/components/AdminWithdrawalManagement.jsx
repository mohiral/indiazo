"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { FaCheckCircle, FaTimesCircle, FaSearch, FaMoneyBillWave, FaFilter } from "react-icons/fa"

const AdminWithdrawalManagement = () => {
  const [withdrawals, setWithdrawals] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedWithdrawal, setSelectedWithdrawal] = useState(null)
  const [transactionId, setTransactionId] = useState("")
  const [rejectionReason, setRejectionReason] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [showModal, setShowModal] = useState(false)
  const [modalAction, setModalAction] = useState("")

  useEffect(() => {
    fetchWithdrawals()
  }, [])

  const fetchWithdrawals = async () => {
    try {
      const response = await fetch("https://aviatorbackend.alofficialgroup.com/api/admin/all-withdrawals")
      const data = await response.json()
      setWithdrawals(data)
    } catch (error) {
      console.error("Error fetching withdrawals:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleApprove = (withdrawal) => {
    setSelectedWithdrawal(withdrawal)
    setTransactionId("")
    setModalAction("approve")
    setShowModal(true)
  }

  const handleReject = (withdrawal) => {
    setSelectedWithdrawal(withdrawal)
    setRejectionReason("")
    setModalAction("reject")
    setShowModal(true)
  }

  const confirmAction = async () => {
    if (!selectedWithdrawal) return

    setIsProcessing(true)

    try {
      const url = `https://aviatorbackend.alofficialgroup.com/api/admin/update-withdrawal-status/${selectedWithdrawal._id}`
      const payload =
        modalAction === "approve" ? { status: "approved", transactionId } : { status: "rejected", rejectionReason }

      const response = await fetch(url, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      })

      if (response.ok) {
        // Update the local state
        setWithdrawals(
          withdrawals.map((w) =>
            w._id === selectedWithdrawal._id
              ? {
                  ...w,
                  status: modalAction === "approve" ? "approved" : "rejected",
                  ...(modalAction === "approve" ? { transactionId } : { rejectionReason }),
                }
              : w,
          ),
        )
        setShowModal(false)
      } else {
        console.error("Failed to update withdrawal status")
      }
    } catch (error) {
      console.error("Error updating withdrawal status:", error)
    } finally {
      setIsProcessing(false)
    }
  }

  const filteredWithdrawals = withdrawals.filter((withdrawal) => {
    const matchesSearch =
      withdrawal.userName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      withdrawal.userEmail?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      withdrawal.upiId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      withdrawal.accountHolderName?.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || withdrawal.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric",
    })
  }

  const formatTime = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleTimeString("en-IN", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Withdrawal Management</h1>
        <button
          onClick={fetchWithdrawals}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Refresh
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <FaSearch className="text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search by name, email, UPI ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 w-full border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        <div className="flex items-center gap-2">
          <FaFilter className="text-gray-500" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Withdrawals Table */}
      {filteredWithdrawals.length === 0 ? (
        <div className="text-center py-10 bg-white rounded-lg shadow">
          <FaMoneyBillWave className="mx-auto text-gray-300 text-5xl mb-4" />
          <h3 className="text-xl font-medium text-gray-700 mb-2">No Withdrawals Found</h3>
          <p className="text-gray-500">There are no withdrawal requests matching your filters.</p>
        </div>
      ) : (
        <div className="overflow-x-auto bg-white rounded-lg shadow">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amount
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  UPI Details
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredWithdrawals.map((withdrawal) => (
                <tr key={withdrawal._id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{withdrawal.userName || "Unknown"}</div>
                    <div className="text-sm text-gray-500">{withdrawal.userEmail || "No email"}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-bold text-gray-900">₹{withdrawal.amount.toFixed(2)}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{withdrawal.upiId}</div>
                    <div className="text-sm text-gray-500">{withdrawal.accountHolderName}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{formatDate(withdrawal.createdAt)}</div>
                    <div className="text-sm text-gray-500">{formatTime(withdrawal.createdAt)}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        withdrawal.status === "pending"
                          ? "bg-yellow-100 text-yellow-800"
                          : withdrawal.status === "approved"
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                      }`}
                    >
                      {withdrawal.status.charAt(0).toUpperCase() + withdrawal.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    {withdrawal.status === "pending" && (
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleApprove(withdrawal)}
                          className="text-green-600 hover:text-green-900"
                        >
                          Approve
                        </button>
                        <button onClick={() => handleReject(withdrawal)} className="text-red-600 hover:text-red-900">
                          Reject
                        </button>
                      </div>
                    )}
                    {withdrawal.status === "approved" && (
                      <div className="text-green-600">
                        {withdrawal.transactionId ? `ID: ${withdrawal.transactionId}` : "Approved"}
                      </div>
                    )}
                    {withdrawal.status === "rejected" && (
                      <div className="text-red-600">
                        {withdrawal.rejectionReason ? withdrawal.rejectionReason : "Rejected"}
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal for Approve/Reject */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-lg shadow-xl max-w-md w-full p-6"
          >
            <h3 className="text-xl font-bold mb-4">
              {modalAction === "approve" ? "Approve Withdrawal" : "Reject Withdrawal"}
            </h3>

            <div className="mb-4 p-4 bg-gray-50 rounded-lg">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <p className="text-gray-500">User:</p>
                  <p className="font-medium">{selectedWithdrawal?.userName}</p>
                </div>
                <div>
                  <p className="text-gray-500">Amount:</p>
                  <p className="font-medium">₹{selectedWithdrawal?.amount.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-gray-500">UPI ID:</p>
                  <p className="font-medium">{selectedWithdrawal?.upiId}</p>
                </div>
                <div>
                  <p className="text-gray-500">Account Name:</p>
                  <p className="font-medium">{selectedWithdrawal?.accountHolderName}</p>
                </div>
              </div>
            </div>

            {modalAction === "approve" ? (
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-medium mb-2">Transaction ID (Optional)</label>
                <input
                  type="text"
                  value={transactionId}
                  onChange={(e) => setTransactionId(e.target.value)}
                  placeholder="Enter transaction ID"
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            ) : (
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-medium mb-2">Reason for Rejection</label>
                <textarea
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  placeholder="Enter reason for rejection"
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  rows={3}
                  required
                />
              </div>
            )}

            <div className="flex justify-end space-x-3">
              <button onClick={() => setShowModal(false)} className="px-4 py-2 border rounded-lg hover:bg-gray-100">
                Cancel
              </button>
              <button
                onClick={confirmAction}
                disabled={isProcessing || (modalAction === "reject" && !rejectionReason)}
                className={`px-4 py-2 rounded-lg text-white flex items-center ${
                  modalAction === "approve" ? "bg-green-600 hover:bg-green-700" : "bg-red-600 hover:bg-red-700"
                } ${
                  isProcessing || (modalAction === "reject" && !rejectionReason) ? "opacity-50 cursor-not-allowed" : ""
                }`}
              >
                {isProcessing ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white mr-2"></div>
                    Processing...
                  </>
                ) : modalAction === "approve" ? (
                  <>
                    <FaCheckCircle className="mr-2" /> Confirm Approval
                  </>
                ) : (
                  <>
                    <FaTimesCircle className="mr-2" /> Confirm Rejection
                  </>
                )}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  )
}

export default AdminWithdrawalManagement

